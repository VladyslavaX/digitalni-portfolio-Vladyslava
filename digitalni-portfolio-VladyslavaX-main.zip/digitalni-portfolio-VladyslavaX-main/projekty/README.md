Větší samostatné práce
